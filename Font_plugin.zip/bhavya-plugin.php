<?php
/**
 * @package BhavyaLogin
 */
/*
Plugin Name: Bhavya Plugin
Plugin URI: http://localhost/wordpress/wp-admin/index.php
Description: This is my first attempt on writing a custom Plugin fornthis amazing tutorial series.
Version: 1.0.0
Author: Bhavya Shah
Author URI: https://com62428.wordpress.com
License: GPLv2 or later
Text Domain: bhavya-plugin
*/
class BhavyaPlugin{
    function __construct()
    {
        add_action('init',array($this, 'custom_post_type'));
    }
    // function activation(){
      // $this-> custom_post_type();   // Cannnot access the 2nd method of the same class by simply sating its name. to use that this is used (flush method is global so can be used)
      // flush_rewrite_rules(); // to save the data once its deactivated or activated accidentally 
    // }

    function uninstall(){
    
    }
    function custom_post_type(){
        register_post_type('book',['public'=> true, 'label'=>'Books']);
    }

    function register(){
      // admin_enqueue_scripts -> Backend
      //wp_enqueue_scripts -> Frontend 
      add_action('admin_enqueue_scripts', array($this,'enqueue'));
    }
    function enqueue(){
      wp_enqueue_style('mypluginstyle', plugins_url('/assests/style.css', __FILE__));
      wp_enqueue_script('mypluginscript', plugins_url('/assests/script.js', __FILE__));
    } 

    // function profile_scripts(){
    //   $src_js = plugin_dir_url(__FILE__).'assests/script.js';
    //   $ver_js = filemtime( plugin_dir_url(__FILE__).'assests/profile.js');

    //   $src_css = plugin_dir_url(__FILE__).'assests/style.css';
    //   $ver_css = filemtime(plugin_dir_url(__FILE__).'assests/profile.css');

    //   wp_enqueue_script('profile-js',$src_js,array('jquery'), $ver_js,true);
    //   wp_enqueue_style('popup-style',$src_css, , $ver_css,true);

    // }
    // add_action('wp_enqueue_scripts','profile_scripts');
}

// echo(plugin_dir_url(__FILE__));

function profile_scripts(){
  $path_js = plugins_url('assessts/profile.js',__FILE__);
  $path_style = plugins_url('assests/profile.css',__FILE__);
  $dep = array('jquery');
  // $ver = filemtime(plugin_dir_path(__FILE__).'assessts/profile.js');
  // $ver_style = filemtime(plugin_dir_path(__FILE__).'assessts/profile.css');
  // $is_login = is_user_logged_in() ? 1:0;
  

  if(is_page('services')){
    wp_enqueue_style('my-custom-style',$path_style, '' );
    wp_enqueue_script('my-custom-js', $path_js , $dep , true);
  }

}
add_action('wp_enqueue_scripts','profile_scripts');
// BhavyaPluginActivate::activate(); // for static method. 

function fonts_plugin(){
  echo('hi');
}

function admin_menu_plugin(){
  add_menu_page('Font Type', 'font type', 'manage_options', 'font-plugin', 'fonts_plugin','',40);
}
add_action('admin_menu','admin_menu_plugin');


if(class_exists('BhavyaPlugin')){
$bhavyaPlugin = new BhavyaPlugin();
$bhavyaPlugin->register();   // triggering the register method with the instance of class   
}
//activation
require_once plugin_dir_path(__FILE__).'inc/bhavya-plugin-activate.php';
register_activation_hook( __FILE__,array('BhavyaPluginActivate','activate'));

//deactivation
require_once plugin_dir_path(__FILE__).'inc/bhavya-plugin-deactivate.php';
register_deactivation_hook( __FILE__,array('BhavyaPluginDeactivate','deactivate'));

